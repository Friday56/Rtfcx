import os
print("Текущая рабочая директория:", os.getcwd())
print("Содержимое папки:", os.listdir('.'))
